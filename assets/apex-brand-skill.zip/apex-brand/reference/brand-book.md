# Apex brand book

From the Apex design system: https://claude.ai/artifact/D5DcpRYwoqvQGGRoEkxVFx

Different is better than better. Simplicity is the core of the brand: two colours, one typeface, one idea at a time.

## Strategy

Most AI startups go too far down the product and features route and never invest in their audience's feelings and identity. Users don't buy features. They buy what the product can help them become.

Apex repackages an AI product into something people can believe in. The transformational identity is made accessible through association with the brand. A strong brand has presence and communicates value before any money moves.

The primary audience is business owners. They are the main decision maker, overwhelmed with choices all day, and every email, decision and follow-up goes through them. Chaos is the enemy. They see the free entrepreneur's lifestyle and want it: time with family, or on the work that makes them the most money. Creators are the secondary audience. Their face is the brand and their inbox is the business, so they spend more time managing than creating.

## The story

The brand lives in the mountains. The customer is a hiker caught in the forest, looking for the summit. The forest is the chaos of doing everything yourself. The trail is the way out. Apex is the guide. The summit is freedom, and it is also the name.

Apex is always the guide, never the hero. The customer reaches the summit.

- Business owners go from "I feel like the whole business rests on my shoulders and if I step away everything falls apart." to "I'm the kind of person who leads a business that runs without me, so I can be fully present for the work and the people that matter most."
- Creators go from "Running the business behind my brand is burning out the creativity that I used to build it." to "I'm the kind of person who creates from inspiration because the business behind my brand runs so efficiently."

## Voice

Talk like a guide who has done this climb before: calm, direct, a little rugged.

- Write short declarative sentences. Say one thing.
- Sell who the customer becomes, not the feature list. "Apex is a great product, but humans don't buy features. They buy what the purchase can help them become."
- A headline stands alone. Never put a small heading, eyebrow or kicker above it.
- A subheading is a few words. It never explains the headline. If the headline needs explaining, rewrite the headline.
- Web headlines are uppercase: `display`, `headline`. Slide titles are sentence case and end with a full stop: "The Overview.", "The Theme."
- Write the name as Apex in copy. APEX and APEX.HOST appear only as logotypes. The domain is apex.host.
- No emoji.

## Colour

Only two colours: Pine Green `pine` (#1C3A28) and Misty White `mist` (#ECECE4). No black, no pure white, no accent, no gradients between them.

- Build with the semantic tokens, never raw hex: `surface` for grounds, `ink` for text and marks, `ink-soft` for ledes, labels and nav, `line` for hairlines, `action` and `on-action` for filled controls.
- The Pine theme is the default: `mist` on `pine`. The Mist theme swaps them. Set `data-theme="mist"` or `data-theme="pine"` on any element to flip everything inside it.
- For contrast, flip a block to the other theme with `Panel`. Never add a colour.
- Tints are one of the two colours at an opacity: `ink-soft` at 72%, `line` at 16% on Pine and 20% on Misty White.

## Type

Inter is the only typeface, in `fonts/` at 400, 500, 700, 800 and 900.

- Headlines: 800, tight, uppercase (`display`, `headline`).
- Subheads and buttons: 700 (`subhead`, `button`, `label`).
- Captions and nav: 500 (`caption`).
- Body: 400 (`body`, `lede`, `small`). A big idea or a quote: 500 (`statement`).
- Slides: `slide-title` at 900, `slide-statement` at 800, `slide-caps` at 400 uppercase, `slide-caps-bold` at 700 uppercase.
- Web sizes are fluid. Each style's usage note gives its clamp.

## Layout

Simple, symmetric, generous. Let the colour and the photography do the work.

- Tiles sit in grids 12px apart (`space-12`) with `radius-tile` corners. Photos and tiles are 4:3, wide photos 16:9.
- Page gutters run from `gutter-min` to `gutter-max`; sections from `section-min` to `section-max`.
- Buttons, chips and the toast are pills (`radius-pill`). A `Panel` takes `radius-card`. Slides are square.
- Slides keep `slide-pad-x` margins, the title top left and the content along the bottom. The middle stays empty.

## Lines

Lines are an element, used in moderation.

- A `hairline` in `line` edges the top bar and the tiles. A `stroke-deck` rule in `ink` sits over each slide column and outlines the transformation boxes.
- Never draw lines between list items. Stack items on their own lines with space, no bullets, rules or dividers between them.
- No small decorative dividers, no underlines under headings.

## Surfaces

- The brand is flat. No shadows. The only shadow token is `focus-ring`: a 2px gap in the surface, then 2px of solid ink, on every control.
- Topographic contour lines add depth to flat colour. Use `apex-topo-texture-green.svg` on Pine and `apex-topo-texture-misty-white.svg` on Misty White, full bleed behind type, on slides, merch and documents. Keep it quiet.

## Photography

Raw, dramatic mountain and forest scapes, in greyscale or tinted Pine and Misty White.

- The forest and the climb are the problem: dark, tinted Pine. The summit is freedom: bright and airy.
- Apply `filter: grayscale(1)` to colour photos on the web. In a hero, set the photo at 50% opacity over Pine and fade it into Pine.

## Logos

The mark is a hiker planting a flag at the summit of a mountain he has just conquered. It celebrates freedom and everything it took to get there. The logotype is simple and uniform: it proves the predictability and steadiness a guide needs.

- Use the green set on Misty White and light photos, the white set on Pine and dark photos. Nothing else: only ever Pine Green or Misty White ink.
- Logo + icon is the default. The stacked logo fits square spaces. The icon stands alone on small spaces like a tee chest. The `.host` versions go where the domain matters, like the tee back.
- App tiles are for app icons and favicons.
- Never recolour, outline or stretch a mark.
- Every source file is in the Apex brand files on Playbook: https://www.playbook.com/s/studio-luminary/ghf2rv7jqD2U3LdZXkbcLxru

## Iconography

Solid single-ink silhouettes from the deck: trees, business owner, creator. Each comes in `-green` (Pine ink) and `-white` (Misty White ink). No outline icons, no emoji.

The one interface glyph is the download arrow inside `Button` and `Chip`: a 2px stroke in the current text colour.

## Motion

Quiet and short. Content rises 18px and fades in (opacity .7s ease, transform .9s cubic-bezier(.2, .8, .2, 1)). Buttons lift 2px on hover over .2s. Linked photos scale to 1.03 over .6s. With reduced motion, show everything and move nothing.
