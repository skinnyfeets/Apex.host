# Apex assets

Every file the skill carries, and when to use it.


## Logos

Two sets of SVGs, one per ground. Source: the Apex brand files on Playbook, https://www.playbook.com/s/studio-luminary/ghf2rv7jqD2U3LdZXkbcLxru

`white/` is for Pine and dark photos. Ink: Misty White #ECECE4.

- `apex-logotype-and-icon-white.svg`: logo + icon, the default.
- `apex-logotype-and-icon-white-stack.svg`: stacked logo, for square spaces.
- `apex-logotype.svg`: logotype alone.
- `apex-logotype-host-white.svg`: APEX.HOST logotype.
- `apex-logotype-host-and-icon-white.svg`: APEX.HOST logotype + icon.
- `apex-icon-white.svg`: the hiker icon.
- `apex-icon-with-logotype-host-overlay-white.svg`: the icon with APEX.HOST across it.
- `apex-app-white-with-green-icon.svg`, `apex-app-white-with-green-logotype.svg`, `apex-app-white-with-green-logotype-host.svg`: Misty White app tiles with a Pine mark.

`green/` is for Misty White and light photos. Ink: Pine Green #1C3A28.

- `apex-logotype-with-icon-green.svg`: logo + icon, the default.
- `apex-logotype-with-icon-stack-green.svg`: stacked logo.
- `apex-logotype-green.svg`: logotype alone.
- `apex-logotype-host-green.svg`: APEX.HOST logotype.
- `apex-logotype-host-with-icon-green.svg`: APEX.HOST logotype + icon.
- `apex-icon-green.svg`: the hiker icon.
- `apex-icon-with-logotype-host-overlay-green.svg`: the icon with APEX.HOST across it.
- `apex-app-green-with-white-icon.svg`, `apex-app-green-with-white-logotype.svg`, `apex-app-green-with-white-logotype-host.svg`: Pine app tiles with a Misty White mark.

## Icons

Solid single-ink silhouettes. Use `-green` (Pine Green #1C3A28) on Misty White and `-white` (Misty White #ECECE4) on Pine.

- `apex-icon-trees-green.svg`, `apex-icon-trees-white.svg`: the forest. Visual identity.
- `apex-icon-business-owner-green.svg`, `apex-icon-business-owner-white.svg`: the primary audience.
- `apex-icon-creator-green.svg`, `apex-icon-creator-white.svg`: the secondary audience.

## Textures

Topographic contour lines, full bleed behind content. 1056 × 816, 1px strokes.

- `apex-topo-texture-green.svg`: Pine ground, Misty White lines at 16%. For Pine slides, pages and merch.
- `apex-topo-texture-misty-white.svg`: Misty White ground, Pine lines. For Misty White slides and documents.

Scale with `object-fit: cover`. Don't tile or recolour them.

## Photography

Raw, dramatic mountain and forest scapes. On the web, show them in greyscale (`filter: grayscale(1)`).

- `apex-photo-forest.jpg`: pines under low cloud, in colour. The forest: tint it Pine or set it in greyscale.
- `apex-photo-trail.jpg`: climbers roped up on a rock ridge. The trail.
- `apex-photo-climb.jpg`: a skier hiking a snow slope above the clouds. The climb.
- `apex-photo-ridges.jpg`: layered ridgelines in soft grey.
- `apex-photo-summit.jpg`: a lone hiker on a snow ridge. Freedom. The hero image.

## Merch

Pine garments and goods with Misty White marks.

- `apex-merch-tee-front.jpg`: tee front. The icon small on the chest.
- `apex-merch-tee-back.jpg`: tee back. Topo lines with the APEX.HOST logotype + icon.
- `apex-merch-hoodie.jpg`: hoodie. APEX logotype centred on the chest.
- `apex-merch-bottle.jpg`: bottle. Topo lines wrapped round it, APEX logotype at the base.

## Examples

The logo in action. Photos tinted Pine or Misty White, with the mark in the opposite colour.

- `apex-in-use-1.jpg`: white logo + icon beside a skier on a Pine tinted slope.
- `apex-in-use-2.jpg`: white stacked logo on a Pine tinted peak.
- `apex-in-use-3.jpg`: white icon on a misty Pine forest.
- `apex-in-use-4.jpg`: green logo + icon over a pale range.
- `apex-in-use-5.jpg`: green stacked logo over climbers on Misty White.
- `apex-in-use-6.jpg`: green icon over pale snowy peaks.

Merch and Examples are not included as files. See them in the design system.
