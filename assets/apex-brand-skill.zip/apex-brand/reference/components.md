# Apex components

Guidelines for each component. The matching CSS classes (`ax-…`) are in `assets/apex.css`.


## Button

A pill that does one thing. `primary` is solid `action` with an `on-action` label; `ghost` is transparent with a `stroke-control` outline in `line`.

- Provide the label as children, a verb first: "Download all brand files", "Open page", "View invoice".
- Pass `href` for links, `icon="download"` for downloads. That arrow is the only glyph a button carries.
- One primary per group. Put ghost buttons beside it for the secondary options.
- `size="sm"` in the top bar only.
- Hover lifts 2px. Focus shows `focus-ring`.
- Don't add a second icon, an emoji, or a colour other than the ink.

## Chip

The small download pill inside a tile caption. It carries the download arrow and the file format, nothing else.

- Provide `href` and the format as children: SVG, PNG, JPG, PDF.
- Outline is `stroke-control` in `line`; on hover it fills with `action`.
- Use it only in a `Tile` caption. For anything else use `Button`.

## Hero

The opening of a page: a mountain photo in greyscale at 50% over Pine, fading into Pine, with the `display` headline.

- Provide `image` (from Photography), `title` (two to four words, `\n` for a break) and up to two buttons as children.
- It is always Pine, whatever the page theme.
- The headline stands alone. No eyebrow above it, no subhead below it.
- Use one hero per page.

## Panel

A block flipped to the other theme: Misty White on a Pine page, Pine on a Misty White page. It is how the brand gets contrast without a third colour.

- Provide `theme` (the theme inside the panel) and children. Every token inside swaps, so buttons and text follow.
- Corners are `radius-card`, padding clamp(28px, 5vw, 72px).
- One panel per section at most. Never nest panels.

## SectionHead

A section's `headline`, uppercase, with an optional one or two sentence `lede` below it in `ink-soft`.

- Provide `title` and, only if it adds something, `lede`.
- Nothing goes above the headline: no eyebrow, no kicker, no number.
- The lede never explains the headline. If the headline needs explaining, rewrite the headline.
- Headlines may end with a full stop ("Logos.", "Texture.") or run as a plain statement ("Only 2 brand colours").

## Slide

The deck page: 760 × 574, the topo texture full bleed, the title top left and the content pinned to the bottom.

- Provide `theme`, the matching `texture` (`apex-topo-texture-green.svg` on Pine, `apex-topo-texture-misty-white.svg` on Mist), `title`, `subtitle` and the body as children.
- Margins are `slide-pad-x` at the sides and bottom, `slide-pad-top` at the top. Corners are square.
- Open the deck on Pine with a photo and the logo. Use Mist for the logo and visual identity pages.
- One idea per slide. Leave the middle of the slide empty.

## SlideColumns

Two or three columns along the bottom of a slide, each with one `stroke-deck` rule in `ink`, a `slide-caps` label and a `slide-statement`.

- Provide `columns`: `{ label, text }`. Use `\n` in text for stacked items.
- The rule is the only line. Stacked items sit on their own lines with no rules, bullets or dividers between them.
- Columns are 66px apart.

## SlideTitle

The slide title in `slide-title` with one line under it in `slide-caps`, indented 13px.

- Provide `title` (sentence case, ends with a full stop) and an optional `subtitle` of a few words.
- The subtitle goes under the title, never above it, and never explains it.

## Swatch

A large colour card that copies its hex on click. Only ever two of them: Pine Green and Misty White.

- Provide `name`, `hex`, `rgb` and `tone`. Pair it with `Toast` to confirm the copy.
- Set them side by side at equal size, 12px apart (`space-12`).

## Tile

A captioned figure for a logo, photo or texture, with an optional download `Chip`.

- Provide `src`, `name`, and `href` plus `format` when it downloads.
- `kind="mark"` contains the logo at 72%; `app` at 64%; `photo` covers in greyscale; `texture` covers in colour.
- `ground` puts green marks on `mist` and white marks on `pine`. Never a white mark on Misty White or a green mark on Pine.
- Tiles are 4:3 with `radius-tile` corners and a `hairline` border, in grids 12px apart.

## Toast

A small pill that confirms an action, then leaves after 1.6 seconds.

- Provide the message as children, two or three words: "Copied #1C3A28".
- Fixed 28px above the bottom, centred, `action` fill with an `on-action` label.
- Toggle `show`. It fades and rises 20px over .3s.

## TopBar

The sticky bar across the top of every Apex page: logo left, section links centre, one small button right.

- Provide `logo` (the white logo + icon on Pine, the green one on Misty White), `links` and one `action`.
- Ground is `bar` with a 10px backdrop blur and a `hairline` in `line` along the bottom. That hairline is the only line in the bar.
- Links are `caption` size in `ink-soft`, `ink` on hover. They hide below 900px.
- Keep links to single words. No dropdowns, no icons.

## Transformation

The before and after of the customer, in their own words: two outlined boxes with TO between them.

- Provide `from` and `to` as first-person quotes; the quotation marks are added.
- Boxes are outlined in `stroke-deck` `ink`, text centred in `slide-statement`, TO in Inter 900 at 25px.
- The customer is the hero of both quotes. Apex is never named in them.
