---
name: apex-brand
description: The Apex (apex.host) brand identity and design system. Use whenever you create, edit or review anything for Apex or Apex.host, including web pages, landing pages, UI, slides and decks, documents, emails, social posts, ads, merch mockups and marketing copy, or when asked to make something "on brand" for Apex. Carries the two-colour palette, Inter type scale, logos, icons, topographic textures, photography, CSS tokens and components, and the brand voice.
---

# Apex brand

Apex is an AI product for business owners (primary audience) and creators (secondary). The brand does not sell features. It sells who the customer becomes: someone free from the chaos of doing everything themselves.

Different is better than better. Simplicity is the core of the brand: two colours, one typeface, one idea at a time.

## What's in this skill

| Path | Use it for |
| --- | --- |
| `reference/brand-book.md` | The full brand book: strategy, story, voice, colour, type, layout, lines, logos, photography, motion. Read it before any substantial piece of work. |
| `reference/tokens.json` | Every design token with its exact value and usage note. |
| `reference/components.md` | Guidelines for each component. |
| `reference/assets.md` | What every logo, icon, texture and photo is, and when to use it. |
| `assets/apex.css` | Fonts, all tokens as CSS variables (both themes) and the component classes. |
| `assets/logos/green/`, `assets/logos/white/` | The real logo files, SVG. |
| `assets/icons/` | Solid silhouettes: trees, business owner, creator. |
| `assets/textures/` | Topographic contour textures for Pine and Misty White grounds. |
| `assets/photos/` | Brand photography: forest, trail, climb, ridges, summit. |
| `assets/fonts/` | Inter 400, 500, 700, 800, 900 (OFL licence included). |

Full design system, with live previews: https://claude.ai/artifact/D5DcpRYwoqvQGGRoEkxVFx
Source brand files: https://www.playbook.com/s/studio-luminary/ghf2rv7jqD2U3LdZXkbcLxru

## The story

The brand lives in the mountains. The forest is the chaos of doing everything yourself. The trail is the way out. Apex is the guide. The summit is freedom, and it is also the name.

The customer is the hero and reaches the summit. Apex is always the guide, never the hero.

## Rules that never bend

1. **Two colours only.** Pine Green `#1C3A28` and Misty White `#ECECE4`. No black, no pure white (`#FFFFFF`), no accent colours, no gradients between other hues. A tint is one of the two colours at an opacity.
2. **Inter only.** Headlines 800, subheads and buttons 700, captions 500, body 400.
3. **A headline stands alone.** Never put an eyebrow, kicker or small heading above it. A subheading is a few words and never explains the headline. If the headline needs explaining, rewrite the headline.
4. **Lines are an element, used in moderation.** Never between list items, no decorative dividers, no underlines under headings.
5. **Flat.** No drop shadows. The only shadow is the keyboard focus ring.
6. **Real logos only.** Use the SVGs in `assets/logos/`. Never redraw, retype, recolour, outline or stretch a mark. Green set on Misty White and light photos; white set on Pine and dark photos.
7. **Mountains and forests.** Photography is raw and dramatic, in greyscale or tinted Pine and Misty White. No offices, laptops, handshakes or smiling teams.
8. **No emoji**, in copy or in design.
9. **Mark made-up data.** In a product mockup, label any invented names or numbers "Example" so no one reads them as real.

## Voice

Talk like a guide who has done this climb before: calm, direct, a little rugged.

- Short declarative sentences. Say one thing.
- Sell who the customer becomes, not the feature list: "Humans don't buy features. They buy what the purchase can help them become."
- Speak to how the customer feels: chaos, every decision going through them, wanting time back for family and for the work that matters.
- Write the name as Apex. APEX and APEX.HOST appear only as logotypes. The domain is apex.host.
- No hype, no jargon, no exclamation marks.

## Colour in practice

Build with the semantic tokens in `assets/apex.css`, never raw hex:

| Token | Pine theme (default) | Mist theme |
| --- | --- | --- |
| `--surface` | Pine | Misty White |
| `--ink` | Misty White | Pine |
| `--ink-soft` (ledes, nav, labels) | Misty White 72% | Pine 72% |
| `--line` (hairlines) | Misty White 16% | Pine 20% |
| `--action` / `--on-action` (filled controls) | Misty White / Pine | Pine / Misty White |

Pine is the default ground. Put `data-theme="mist"` on any element to flip everything inside it. For contrast, flip a block to the other theme with a Panel (`.ax-panel`). Never add a colour.

## Type scale (web)

| Style | Weight | Size (fluid) | Notes |
| --- | --- | --- | --- |
| display | 800 | clamp(64px, 15vw, 240px) | Hero only, uppercase, line-height 0.92, tracking -0.04em |
| headline | 800 | clamp(34px, 4.6vw, 64px) | Section headlines, uppercase, tracking -0.035em |
| statement | 500 | clamp(24px, 2.6vw, 38px) | One big idea or a quote, max 28ch |
| subhead | 700 | clamp(20px, 2vw, 28px) | A few words |
| lede | 400 | clamp(17px, 1.4vw, 20px) | `--ink-soft`, max 52ch |
| body | 400 | 17px | |
| button | 700 | 15px | 14px on small buttons |
| caption | 500 | 14px | Tile captions, nav |
| label | 700 | 13px | Uppercase, tracking 0.08em, only above a grid of tiles, never above a headline |
| small | 400 | 13px | Footer, `--ink-soft` |

Web headlines are uppercase. Slide titles are sentence case and end with a full stop.

## Building a web page

- Copy the `assets/` folder next to the page and link `assets/apex.css`, or inline it. It loads Inter from `assets/fonts/`.
- Layout is simple, symmetric and generous. Page gutters `clamp(20px, 5vw, 80px)`, section padding `clamp(64px, 9vw, 120px)`.
- Tiles sit in grids 12px apart with 18px corners (`--radius-tile`). Photos and tiles are 4:3, wide photos 16:9. Panels take 24px corners. Buttons, chips and the toast are pills.
- Hero: a greyscale photo at 50% opacity over Pine, fading into Pine, with the display headline.
- Photos on the web get `filter: grayscale(1)`.
- Topographic texture: `apex-topo-texture-green.svg` on Pine, `apex-topo-texture-misty-white.svg` on Misty White, full bleed behind type, kept quiet. Scale with `object-fit: cover`; don't tile or recolour it.
- Motion is quiet and short. Content rises 18px and fades in (opacity 0.7s ease, transform 0.9s cubic-bezier(.2,.8,.2,1)). Buttons lift 2px on hover over 0.2s. With reduced motion, show everything and move nothing.

### Components and their classes

| Component | Classes in `apex.css` |
| --- | --- |
| Button | `.ax-btn` (primary), `.ax-btn-ghost`, `.ax-btn-sm` (top bar only) |
| Chip (download chip) | `.ax-chip` |
| Top bar | `.ax-bar`, `.ax-bar-logo`, `nav` |
| Hero | `.ax-hero`, `.ax-hero-bg`, `.ax-hero-title`, `.ax-hero-cta` |
| Section head | `.ax-head`, `.ax-headline`, `.ax-lede` |
| Swatch | `.ax-swatch`, `.ax-swatch-pine`, `.ax-swatch-mist` |
| Tile | `.ax-tile`, `.ax-tile-art`, `.ax-tile-ground-mist` / `-pine`, `.ax-tile-mark`, `.ax-tile-app`, `.ax-tile-photo`, `.ax-tile-texture` |
| Panel | `.ax-panel` with `data-theme` set to the opposite theme |
| Toast | `.ax-toast`, `.ax-toast-show` |
| Slide | `.ax-slide`, `.ax-slide-texture`, `.ax-slide-body`, `.ax-slide-title` |
| Slide columns | `.ax-cols`, `.ax-col-rule`, `.ax-col-label`, `.ax-col-text` |
| Transformation | `.ax-transform`, `.ax-transform-box`, `.ax-transform-to` |

`reference/components.md` describes each one. Where it mentions props such as `href` or `icon`, those come from the design system's React bundle; in plain HTML use the classes above. One primary button per group; the download arrow is the only glyph a button carries.

## Slides and documents

- The deck slide is 760 × 574. Keep 45px side margins and a 52px top margin.
- Title top left: Inter 900, about 61px, sentence case, one or two words, ending with a full stop ("The Overview.", "The Theme."). One uppercase line under it at 400, about 16.6px.
- Content sits along the bottom. The middle stays empty.
- A 3px rule in the ink sits over each column, then an uppercase label, then a short statement at 800.
- Use the topographic texture full bleed. Alternate Pine and Misty White slides.

## Logo quick pick

| Need | File |
| --- | --- |
| Default, on Pine or a dark photo | `logos/white/apex-logotype-and-icon-white.svg` |
| Default, on Misty White or a light photo | `logos/green/apex-logotype-with-icon-green.svg` |
| Square space | `apex-logotype-and-icon-white-stack.svg` / `apex-logotype-with-icon-stack-green.svg` |
| Small space (a tee chest, a favicon) | `apex-icon-white.svg` / `apex-icon-green.svg` |
| Where the domain matters | the `logotype-host` files |
| App icon or favicon tile | the `apex-app-…` files |

The mark is a hiker planting a flag at the summit of a mountain he has just conquered. The logotype is simple and uniform, as steady as a guide should be.

## Before you finish

- Only Pine Green and Misty White, with no black, pure white or third colour?
- Inter only, with uppercase web headlines?
- No eyebrow above a headline, no subheading explaining it, no lines between list items?
- The right logo set for the ground, using the real file?
- Photography of mountains or forests, in greyscale or brand tint?
- Does the copy sound like a calm guide, with the customer as the hero?
- Any made-up names or numbers marked "Example"?
